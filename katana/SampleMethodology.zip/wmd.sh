#!/bin/sh

#######################################################################
# You will need to run "gem install wayback_machine_downloader" first
# if you do not already have it.
#
# Takes input file as first argument and output dir as second argument
# 
# Last Edited: 06-05-2017
#######################################################################

file="$1"
dir="$2"

##### Color output
GREEN="\033[01;32m"		# Success
BLUE="\033[01;34m"		# Heading
RESET='\033[00m'		# Normal

clear;echo "${BLUE}Wayback Machine Downloader started...${RESET}"
for line in $(cat $file);
do echo;mkdir $dir/$line;echo "${BLUE}Downloading Internet Archive of: " $line ${RESET};wayback_machine_downloader $line -d $dir/$line #--only "/\.(txt|doc|docx|pdf|ppt|pptx|xls|xlsx|pps|ppsx|odt|ods|svg|rdp)$/i"
	echo "${GREEN}Completed download of: " $line ${RESET}
done;
